

killall client_process
sleep 1
killall server_process

